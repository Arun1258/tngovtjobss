<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('job/(:num)', 'Home::detail/$1');
$routes->get('jobs/category/(:segment)', 'Home::category/$1');

$routes->get('admin/home', 'Admin\Home::index');
$routes->get('admin/login', 'Admin\AdminController::login');
$routes->post('admin/loginCheck', 'Admin\AdminController::loginCheck');
$routes->get('admin/logout', 'Admin\AdminController::logout');
$routes->group('admin', ['namespace' => 'App\Controllers\Admin'], function($routes) {
    $routes->get('jobs', 'Jobs::index');
    $routes->get('jobs/create', 'Jobs::create');
    $routes->post('jobs/store', 'Jobs::store');
    $routes->get('jobs/edit/(:num)', 'Jobs::edit/$1');
    $routes->post('jobs/update/(:num)', 'Jobs::update/$1');
    $routes->get('jobs/delete/(:num)', 'Jobs::delete/$1');
});
