<?php namespace App\Models;

use CodeIgniter\Model;

class JobModel extends Model
{
    protected $table = 'jobs';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'jobtype', 'title', 'department', 'location', 'qualification', 'salary','apply_link','description','image'
    ];
    protected $useTimestamps = true;
}
