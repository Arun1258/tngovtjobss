<?php

namespace App\Controllers;

use App\Models\JobModel;

class Home extends BaseController
{
    public function index(): string
    {
        $model = new JobModel();

        // Govt Job Types
        $govtTypes = [
            'TN Govt Jobs',
            'Central Govt Jobs',
            'TNPSC Jobs',
            'Railway Jobs',
            'Bank Jobs'
        ];

        // Get Government Jobs
        // $data['govtJobs'] = $model->whereIn('jobtype', $govtTypes)->findAll();
        $data['govtJobs'] = $model
    ->whereIn('jobtype', $govtTypes)
    ->orderBy('id', 'DESC')
    ->findAll();
    $data['privateJobs'] = $model
    ->where('jobtype', 'Private Jobs')
    ->orderBy('id', 'DESC')
    ->findAll();


        // Get Private Jobs
        $data['privateJobs'] = $model->where('jobtype', 'Private Jobs')->findAll();

        return view('home', $data);
    }
    public function detail($id)
    {
        $model = new JobModel();
        $job = $model->find($id);
    
        if (!$job) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound("Job not found");
        }
    
        return view('job_detail', ['job' => $job]);
    }
    public function category($type)
    {
        $model = new JobModel();

        // Replace hyphens with spaces (tn-govt → tn govt)
        $jobType = str_replace('-', ' ', $type);

        // Fetch related jobs
        $data['jobs'] = $model
            ->where('jobtype', $jobType)
            ->orderBy('id', 'DESC')
            ->findAll();

        // Pass category title
        $data['title'] = ucwords($jobType);

        return view('category', $data);
    }
    
}
