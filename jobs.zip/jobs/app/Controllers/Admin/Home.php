<?php namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\JobModel;

class Home extends BaseController
{
    public function index()
    {
        if (!session()->get('isLoggedInAdmin')) {
            return redirect()->to('/admin/login');
        }
    
        return view('admin/home');
    }
    
}