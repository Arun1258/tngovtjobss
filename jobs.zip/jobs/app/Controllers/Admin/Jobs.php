<?php namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\JobModel;

class Jobs extends BaseController
{
    public function index()
    {
        if (!session()->get('isLoggedInAdmin')) {
            return redirect()->to('/admin/login');
        }
        $model = new JobModel();
        $data['jobs'] = $model->orderBy('id', 'DESC')->findAll();
        return view('admin/jobs/view_jobs', $data);
    }

    public function create()
    {
        return view('admin/jobs/add_jobs');
    }

    public function store()
    {
        $model = new JobModel();
    
        $imageFile = $this->request->getFile('image');
    
        // Default image if no upload
        $imageName = "default.png";
    
        // If user selected a file and it's valid
        if ($imageFile && $imageFile->isValid() && !$imageFile->hasMoved()) {
            $imageName = $imageFile->getRandomName();
            $imageFile->move('uploads/jobs/', $imageName);
        }
    
        $data = [
            'jobtype'       => $this->request->getPost('jobtype'),
            'title'         => $this->request->getPost('title'),
            'department'    => $this->request->getPost('department'),
            'description'   => $this->request->getPost('description'),
            'image'         => $imageName,
            'location'      => $this->request->getPost('location'),
            'qualification' => $this->request->getPost('qualification'),
            'salary'        => $this->request->getPost('salary'),
            'apply_link'   => $this->request->getPost('apply_link'),
        ];
    
        $model->insert($data);
    
        return redirect()->to('/admin/jobs')->with('success', 'Job added successfully.');
    }
    

    public function edit($id)
    {
        $model = new JobModel();
        $data['job'] = $model->find($id);
        return view('admin/jobs/edit_jobs', $data);
    }

    public function update($id)
    {
        $model = new JobModel();
        $imageFile = $this->request->getFile('image');
        $imageName = null;
    
        if ($imageFile && $imageFile->isValid()) {
            $imageName = $imageFile->getRandomName();
            $imageFile->move('uploads/jobs/', $imageName);
        }
        $data = [
            'jobtype' => $this->request->getPost('jobtype'),
            'title' => $this->request->getPost('title'),
            'department' => $this->request->getPost('department'),
            'description' => $this->request->getPost('description'),
            'image'        => $imageName,

            'location' => $this->request->getPost('location'),
            'qualification' => $this->request->getPost('qualification'),
            'salary' => $this->request->getPost('salary'),
            'apply_link'   => $this->request->getPost('apply_link'),

        ];
        $model->update($id, $data);
        return redirect()->to('/admin/jobs')->with('success', 'Job updated successfully.');
    }

    public function delete($id)
    {
        $model = new JobModel();
        $model->delete($id);
        return redirect()->to('/admin/jobs')->with('success', 'Job deleted successfully.');
    }
}
