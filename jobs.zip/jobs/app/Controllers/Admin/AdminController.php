<?php

namespace App\Controllers\Admin;

use App\Models\AdminModel;
use App\Controllers\BaseController;

class AdminController extends BaseController
{
    public function login()
    {
        return view('admin/login');
    }

    public function loginCheck()
    {
        $username = $this->request->getPost('username');
        $password = hash('sha256', $this->request->getPost('password')); // SHA256 HASH

        $adminModel = new AdminModel();

        $admin = $adminModel->where('username', $username)
                            ->where('password', $password)
                            ->first();

        if ($admin) {
            // Store session
            session()->set([
                'admin_id' => $admin['id'],
                'admin_username' => $admin['username'],
                'isLoggedInAdmin' => true
            ]);

            return redirect()->to('/admin/home');
        }

        return redirect()->back()->with('error', 'Invalid Username or Password');
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/admin/login');
    }
}
