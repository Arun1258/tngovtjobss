<div class="sidebar">
    <ul class="nav flex-column px-3">

        <li class="nav-item mb-2">
            <a class="nav-link" href="<?= base_url('admin/home') ?>">
                <i class="bi bi-speedometer2"></i> Dashboard
            </a>
        </li>

        <li class="nav-item mb-2">
            <a class="nav-link" href="<?= base_url('admin/jobs') ?>">
                <i class="bi bi-briefcase"></i> Jobs
            </a>
        </li>

    </ul>
</div>
