<?= $this->include('admin/header') ?>
<?= $this->include('admin/sidebar') ?>

<!-- <div class="content">
    <div class="container-fluid">

        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body">
                <h4 class="fw-bold text-primary mb-3">Dashboard</h4>
                <p>Welcome to your new sky-blue admin panel!</p>
            </div>
        </div>

    </div>
</div> -->

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
