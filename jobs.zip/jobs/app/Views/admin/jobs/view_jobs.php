<?= $this->include('admin/header') ?>
<?= $this->include('admin/sidebar') ?>
<link rel="stylesheet" 
href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">

<main id="main">

  <div class="d-flex justify-content-between align-items-center mb-3">
      <h2 class="fw-bold text-primary">Jobs List</h2>
      <a href="<?= base_url('admin/jobs/create') ?>" class="btn btn-info text-white">
        <i class="bi bi-plus-circle"></i> Add Job
      </a>
  </div>

  <?php if(session()->getFlashdata('success')): ?>
    <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
  <?php endif; ?>

  <div class="card shadow-sm">
    <div class="card-body">

    <table id="jobsTable" class="table table-striped table-bordered align-middle">
        <thead class="table-info">
          <tr>
            <th>ID</th>
            <th>Type</th>
            <th>Title</th>
            <th>Department</th>
            <th>Location</th>
            <th>Qualification</th>
            <th>Salary</th>
            <th>Action</th>
          </tr>
        </thead>

        <tbody>
        <?php foreach($jobs as $job): ?>
          <tr>
            <td><?= $job['id'] ?></td>
            <td><?= $job['jobtype'] ?></td>
            <td><?= $job['title'] ?></td>
            <td><?= $job['department'] ?></td>
            <td><?= $job['location'] ?></td>
            <td><?= $job['qualification'] ?></td>
            <td><?= $job['salary'] ?></td>
            <td>
              <a href="<?= base_url('admin/jobs/edit/'.$job['id']) ?>" class="btn btn-warning btn-sm">Edit</a>
              <a href="<?= base_url('admin/jobs/delete/'.$job['id']) ?>" 
                 onclick="return confirm('Delete this job?')" 
                 class="btn btn-danger btn-sm">Delete</a>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>

    </div>
  </div>

</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

<script>
  $(document).ready(function() {
      $('#jobsTable').DataTable({
          "pageLength": 10,
          "lengthMenu": [5, 10, 25, 50, 100],
          "ordering": true,
          "order": [[0, "desc"]],
      });
  });
</script>
