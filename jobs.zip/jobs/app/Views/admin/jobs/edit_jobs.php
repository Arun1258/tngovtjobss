<?= $this->include('admin/header') ?> 
<?= $this->include('admin/sidebar') ?>

<main id="main" class="main">

  <div class="pagetitle">
    <h1>Edit Job</h1>
  </div>

  <!-- IMPORTANT: enctype added -->
  <form action="<?= base_url('admin/jobs/update/'.$job['id']) ?>" 
        method="post" 
        enctype="multipart/form-data">

    <div class="mb-3">
      <label>Job Type</label>
      <select name="jobtype" class="form-control" required>
        <option value="TN Govt Jobs" <?= ($job['jobtype'] == 'TN Govt Jobs') ? 'selected' : '' ?>>TN Govt Jobs</option>
        <option value="Central Govt Jobs" <?= ($job['jobtype'] == 'Central Govt Jobs') ? 'selected' : '' ?>>Central Govt Jobs</option>
        <option value="TNPSC Jobs" <?= ($job['jobtype'] == 'TNPSC Jobs') ? 'selected' : '' ?>>TNPSC Jobs</option>
        <option value="Bank Jobs" <?= ($job['jobtype'] == 'Bank Jobs') ? 'selected' : '' ?>>Bank Jobs</option>
        <option value="Railway Jobs" <?= ($job['jobtype'] == 'Railway Jobs') ? 'selected' : '' ?>>Railway Jobs</option>
        <option value="Private Jobs" <?= ($job['jobtype'] == 'Private Jobs') ? 'selected' : '' ?>>Private Jobs</option>
      </select>
    </div>

    <div class="mb-3">
      <label>Job Title</label>
      <input type="text" name="title" class="form-control" value="<?= $job['title'] ?>" required>
    </div>

    <div class="mb-3">
      <label>Department</label>
      <input type="text" name="department" class="form-control" value="<?= $job['department'] ?>">
    </div>

    <div class="mb-3">
      <label>Description</label>
      <textarea name="description" class="form-control" rows="4"><?= $job['description'] ?></textarea>
    </div>

    <div class="mb-3">
      <label>Location</label>
      <input type="text" name="location" class="form-control" value="<?= $job['location'] ?>">
    </div>

    <div class="mb-3">
      <label>Qualification</label>
      <input type="text" name="qualification" class="form-control" value="<?= $job['qualification'] ?>">
    </div>

    <div class="mb-3">
      <label>Salary</label>
      <input type="text" name="salary" class="form-control" value="<?= $job['salary'] ?>">
    </div>

    <!-- IMAGE UPLOAD -->
    <div class="mb-3">
      <label>Job Image</label>
      <input type="file" name="image" class="form-control">

      <?php if (!empty($job['image'])): ?>
        <div class="mt-2">
          <p>Current Image:</p>
          <img src="<?= base_url('uploads/jobs/'.$job['image']) ?>" 
               width="150" 
               class="img-thumbnail">
        </div>
      <?php endif; ?>
    </div>
    <div class="mb-3">
      <label>Apply Link</label>
      <input type="url" name="apply_link" class="form-control" 
             value="<?= $job['apply_link'] ?>" 
             placeholder="https://example.com/apply" required>
    </div>
    <button type="submit" class="btn btn-primary">Update</button>
    <a href="<?= base_url('admin/jobs') ?>" class="btn btn-secondary">Back</a>

  </form>

</main>
