<?= $this->include('admin/header') ?>
<?= $this->include('admin/sidebar') ?>

<main id="main" class="main">
  <h4>Add New Job</h4>
  <form action="<?= base_url('admin/jobs/store') ?>" method="post" enctype="multipart/form-data">

<div class="mb-3">
  <label>Job Type</label>
  <select name="jobtype" class="form-control" required>
      <option value="TN Govt Jobs">TN Govt Jobs</option>
      <option value="Central Govt Jobs">Central Govt Jobs</option>
      <option value="TNPSC Jobs">TNPSC Jobs</option>
      <option value="Bank Jobs">Bank Jobs</option>
      <option value="Railway Jobs">Railway Jobs</option>
      <option value="Private Jobs">Private Jobs</option>
  </select>
</div>

<div class="mb-3">
  <label>Job Title</label>
  <input type="text" name="title" class="form-control" required>
</div>

<div class="mb-3">
  <label>Department</label>
  <input type="text" name="department" class="form-control">
</div>

<div class="mb-3">
  <label>Description</label>
  <textarea name="description" class="form-control" rows="4"></textarea>
</div>

<div class="mb-3">
  <label>Location</label>
  <input type="text" name="location" class="form-control">
</div>

<div class="mb-3">
  <label>Qualification</label>
  <input type="text" name="qualification" class="form-control">
</div>

<div class="mb-3">
  <label>Salary</label>
  <input type="text" name="salary" class="form-control">
</div>

<div class="mb-3">
  <label>Job Image</label>
  <input type="file" name="image" class="form-control">
</div>
<div class="mb-3">
  <label>Apply Link</label>
  <input type="url" name="apply_link" class="form-control" required>
</div>

<button type="submit" class="btn btn-success">Save</button>
<a href="<?= base_url('admin/jobs') ?>" class="btn btn-secondary">Back</a>
</form>

</main>

