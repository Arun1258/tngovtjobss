<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Admin Dashboard</title>

  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

  <!-- SKY BLUE THEME -->
  <style>
      body { background: #f0f8ff; } /* AliceBlue = soft sky */
      .main-header {
          background: #0ea5e9; /* Sky blue */
          color: #fff;
          padding: 12px 20px;
      }
      .sidebar {
          width: 240px;
          background: #e0f2fe; /* very light sky */
          height: 100vh;
          padding-top: 20px;
          position: fixed;
      }
      .sidebar a {
          color: #0369a1;
          font-weight: 600;
      }
      .sidebar a:hover {
          background: #bae6fd;
          color: #0c4a6e;
      }
      #main {
          margin-left: 250px;
          padding: 25px;
      }
  </style>
</head>

<body>

<header class="main-header d-flex justify-content-between align-items-center">
    <h4 class="m-0 text-white">Admin Panel</h4>
    <div class="d-flex align-items-center">
        <span class="me-3 text-white"><?= session()->get('username') ?? 'Admin' ?></span>
        <a href="<?= base_url('admin/logout') ?>" class="btn btn-light btn-sm">Logout</a>
    </div>
</header>
