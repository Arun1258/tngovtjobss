   <?php echo view('header'); ?>
   <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">

   <!-- Enhanced Banner -->
   <section class="container mt-5">
        <div class="enhanced-banner">
            <h1>Welcome to Tamil Nadu Job Portal</h1>
            <p>Find your dream job with verified listings, premium features, and an interactive experience built just for you.</p>
            <button class="btn btn-custom">Explore Jobs</button>
        </div>
    </section>

    <!-- Admin Panel -->
    <section id="adminPanel" class="container mt-5 admin-panel">
        <div id="adminLogin" class="login-form">
            <h2 class="text-center mb-4">Admin Login</h2>
            <div class="form-group">
                <label class="form-label">Username</label>
                <input type="text" id="adminUsername" class="form-control" placeholder="Enter username">
            </div>
            <div class="form-group">
                <label class="form-label">Password</label>
                <input type="password" id="adminPassword" class="form-control" placeholder="Enter password">
            </div>
            <button id="loginBtn" class="admin-btn">Login</button>
        </div>

        <div id="adminJobForm" class="job-form">
            <h2 class="text-center mb-4">Add New Job</h2>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="form-label">Job Title</label>
                        <input type="text" id="jobTitle" class="form-control" placeholder="Enter job title">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="form-label">Department/Company</label>
                        <input type="text" id="jobDept" class="form-control" placeholder="Enter department or company">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="form-label">Location</label>
                        <input type="text" id="jobLocation" class="form-control" placeholder="Enter location">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="form-label">Qualification</label>
                        <input type="text" id="jobQualification" class="form-control" placeholder="Enter qualification">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="form-label">Salary</label>
                        <input type="text" id="jobSalary" class="form-control" placeholder="Enter salary">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="form-label">Job Category</label>
                        <select id="jobCategory" class="form-control">
                            <option value="govt">Government Job</option>
                            <option value="private">Private Job</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="d-flex gap-2 mt-4">
                <button id="addJobBtn" class="admin-btn">Add Job</button>
                <button id="logoutBtn" class="admin-btn secondary">Logout</button>
            </div>
        </div>
    </section>

    <!-- Filter + Job List -->
    <main id="jobs" class="container mt-5 mb-5">
        <div class="filter-section mb-5">
            <div class="d-flex flex-column flex-md-row gap-3">
                <input id="searchInput" type="text" 
                       class="search-input flex-grow-1" 
                       placeholder="🔍 Search by title, dept, or location">
                
                <select id="deptFilter" class="dept-select">
                    <option value="">All Departments</option>
                    <option value="TNPSC">TNPSC</option>
                    <option value="RAILWAY">Railway</option>
                    <option value="BANK">Banking</option>
                    <option value="IT">IT</option>
                    <option value="MARKETING">Marketing</option>
                    <option value="HR">HR</option>
                    <option value="CENTRAL">Central</option>
                </select>
                
                <button id="clearBtn" class="clear-btn">Clear</button>
            </div>
        </div>

        
        <!-- Job Tables -->
        <!-- Government Jobs Table -->
        <div id="govt-table" class="job-section">
            <h2>🏛 Government Jobs</h2>
            <div class="table-container">
                <table id="govtJobsTable">
                    <thead>
                        <tr>
                            <th>S.No</th>
                            <th>Job Title</th>
                            <th>Department</th>
                            <th>Location</th>
                            <th>Qualification</th>
                            <th>Salary</th>
                            <th>Apply</th>
                        </tr>
                    </thead>
                    <tbody id="govtJobsBody">
    <?php $i = 1; ?>
    <?php foreach ($govtJobs as $job): ?>
        <tr>
            <td><?= $i++ ?></td>
            <td><?= esc($job['title']) ?></td>
            <td><?= esc($job['department']) ?></td>
            <td><?= esc($job['location']) ?></td>
            <td><?= esc($job['qualification']) ?></td>
            <td><?= esc($job['salary']) ?></td>
            <td>
    <a href="<?= site_url('job/' . $job['id']) ?>" class="apply-btn" style="text-decoration:none;">
        Apply Now
    </a>
</td>
        </tr>
    <?php endforeach; ?>
</tbody>

                </table>
            </div>
        </div>

        <!-- Private Jobs Table -->
        <div id="private-table" class="job-section">
            <h2>💼 Private Jobs</h2>
            <div class="table-container">
                <table id="privateJobsTable">
                    <thead>
                        <tr>
                            <th>S.No</th>
                            <th>Job Title</th>
                            <th>Company</th>
                            <th>Location</th>
                            <th>Qualification</th>
                            <th>Salary</th>
                            <th>Apply</th>
                        </tr>
                    </thead>
                    <tbody id="privateJobsBody">
    <?php $i = 1; ?>
    <?php foreach ($privateJobs as $job): ?>
        <tr>
            <td><?= $i++ ?></td>
            <td><?= esc($job['title']) ?></td>
            <td><?= esc($job['department']) ?></td>
            <td><?= esc($job['location']) ?></td>
            <td><?= esc($job['qualification']) ?></td>
            <td><?= esc($job['salary']) ?></td>
<td>
    <a href="<?= site_url('job/' . $job['id']) ?>" class="apply-btn" style="text-decoration:none;">
        Apply Now
    </a>
</td>
        </tr>
    <?php endforeach; ?>
</tbody>

                </table>
            </div>
        </div>
    </main>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<script>
$(document).ready(function() {

    $('#govtJobsTable').DataTable({
        pageLength: 5,
        lengthMenu: [5, 10, 25, 50, 100],
        ordering: true,
        order: [[0, "asc"]],
        responsive: true
    });

    $('#privateJobsTable').DataTable({
        pageLength: 5,
        lengthMenu: [5, 10, 25, 50, 100],
        ordering: true,
        order: [[0, "asc"]],
        responsive: true
    });

});
</script>
<style>
    #govtJobsTable th, 
    #govtJobsTable td,
    #privateJobsTable th, 
    #privateJobsTable td {
        padding: 16px !important;
    }
</style>

    <?php echo view('footer'); ?>
