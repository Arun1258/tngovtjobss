<?= $this->include('header') ?>

<div class="container mt-5">
    <h2 class="mb-4"><?= esc($title) ?></h2>

    <?php if (empty($jobs)): ?>
        <div class="alert alert-warning">No jobs available in this category.</div>
    <?php else: ?>
        <div class="row">
            <?php foreach ($jobs as $job): ?>
                <div class="col-md-4 mb-4">
                    <div class="card shadow-sm">

                        <?php if ($job['image']): ?>
                            <img src="<?= base_url('uploads/jobs/'.$job['image']) ?>" class="card-img-top" height="180">
                        <?php endif; ?>

                        <div class="card-body">
                            <h5 class="card-title"><?= esc($job['title']) ?></h5>
                            <p class="card-text">
                                <strong>Dept:</strong> <?= esc($job['department']) ?><br>
                                <strong>Location:</strong> <?= esc($job['location']) ?><br>
                                <strong>Qualification:</strong> <?= esc($job['qualification']) ?><br>
                                <strong>Salary:</strong> <?= esc($job['salary']) ?>
                            </p>

                            <a href="<?= site_url('job/' . $job['id']) ?>" 
   class="btn btn-primary btn-sm">
   Apply Now
</a>


                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

</div>

<?= $this->include('footer') ?>
