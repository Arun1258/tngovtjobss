<?php echo view('header'); ?>

<style>
.job-detail-wrapper {
    max-width: 850px;
    margin: 30px auto;
    background: #e6f4ff; /* light sky blue */
    border-radius: 12px;
    padding: 25px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}

.job-detail-header {
    display: flex;
    align-items: center;
    gap: 20px;
}

.job-image {
    width: 130px;
    height: 130px;
    border-radius: 10px;
    object-fit: cover;
    border: 3px solid #b3e0ff;
}

.job-title {
    font-size: 28px;
    font-weight: bold;
    color: #004f99;
}

.job-info p {
    font-size: 18px;
    margin: 8px 0;
    color: #003d66;
}

.description-box {
    background: white;
    padding: 15px;
    border-radius: 10px;
    border-left: 5px solid #5bb3ff;
    margin-top: 20px;
}

.apply-btn {
    display: inline-block;
    padding: 12px 25px;
    font-size: 18px;
    background: #0099ff;
    color: #fff;
    border-radius: 8px;
    margin-top: 20px;
    text-decoration: none;
    transition: 0.3s;
}

.apply-btn:hover {
    background: #007acc;
}
</style>

<div class="job-detail-wrapper">

    <div class="job-detail-header">
        <?php if (!empty($job['image'])): ?>
            <img src="<?= base_url('uploads/jobs/' . $job['image']) ?>" class="job-image">
        <?php else: ?>
            <img src="<?= base_url('uploads/default-job.png') ?>" class="job-image">
        <?php endif; ?>

        <h1 class="job-title"><?= esc($job['title']) ?></h1>
    </div>

    <div class="job-info">
        <p><strong>Department:</strong> <?= esc($job['department']) ?></p>
        <p><strong>Location:</strong> <?= esc($job['location']) ?></p>
        <p><strong>Qualification:</strong> <?= esc($job['qualification']) ?></p>
        <p><strong>Salary:</strong> ₹<?= esc($job['salary']) ?></p>
        <p><strong>Job Type:</strong> <?= esc($job['jobtype']) ?></p>
    </div>

    <?php if (!empty($job['description'])): ?>
    <div class="description-box">
        <h3 style="color:#005c99;">Job Description</h3>
        <p><?= nl2br(esc($job['description'])) ?></p>
    </div>
    <?php endif; ?>

    <a href="<?= esc($job['apply_link']) ?>" class="apply-btn">Apply Now</a>
</div>

<?php echo view('footer'); ?>
