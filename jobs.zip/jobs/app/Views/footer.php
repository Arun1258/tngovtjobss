<!-- Footer - COMPACT VERSION -->
<footer class="custom-footer text-center">
        <div class="container">
            <h2 class="footer-heading">Get in Touch</h2>
            <p class="footer-description">
                Stay connected with us for daily job updates, alerts & career guidance.
            </p>

            <div class="social-links-compact">
                <a href="https://wa.me/YourNumber" target="_blank" class="social-link-compact whatsapp">
                    <img src="https://cdn.jsdelivr.net/npm/simple-icons@v9/icons/whatsapp.svg" width="16" alt="WhatsApp">
                    <span>WhatsApp</span>
                </a>
                <a href="https://t.me/YourTelegram" target="_blank" class="social-link-compact telegram">
                    <img src="https://cdn.jsdelivr.net/npm/simple-icons@v9/icons/telegram.svg" width="16" alt="Telegram">
                    <span>Telegram</span>
                </a>
                <a href="https://linkedin.com/in/yourprofile" target="_blank" class="social-link-compact linkedin">
                    <img src="https://cdn.jsdelivr.net/npm/simple-icons@v9/icons/linkedin.svg" width="16" alt="LinkedIn">
                    <span>LinkedIn</span>
                </a>
                <a href="https://facebook.com/yourpage" target="_blank" class="social-link-compact facebook">
                    <img src="https://cdn.jsdelivr.net/npm/simple-icons@v9/icons/facebook.svg" width="16" alt="Facebook">
                    <span>Facebook</span>
                </a>
                <a href="https://youtube.com/@yourchannel" target="_blank" class="social-link-compact youtube">
                    <img src="https://cdn.jsdelivr.net/npm/simple-icons@v9/icons/youtube.svg" width="16" alt="YouTube">
                    <span>YouTube</span>
                </a>
                <a href="https://twitter.com/yourprofile" target="_blank" class="social-link-compact twitter">
                    <img src="https://cdn.jsdelivr.net/npm/simple-icons@v9/icons/twitter.svg" width="16" alt="Twitter">
                    <span>Twitter</span>
                </a>
            </div>

            <p class="footer-copyright">
                © Tamil Nadu Job Portal • Designed with ♥ for Aspirants • 2025
            </p>
        </div>
    </footer>

    <!-- Admin Toggle Button -->
    <button id="adminToggle" class="admin-toggle">⚙️</button>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Custom Script -->
    <script>
        // Admin Panel Functionality
        const adminPanel = document.getElementById("adminPanel");
        const adminToggle = document.getElementById("adminToggle");
        const adminLogin = document.getElementById("adminLogin");
        const adminJobForm = document.getElementById("adminJobForm");
        const loginBtn = document.getElementById("loginBtn");
        const logoutBtn = document.getElementById("logoutBtn");
        const addJobBtn = document.getElementById("addJobBtn");
        
        // Job tables
        const govtJobsBody = document.getElementById("govtJobsBody");
        const privateJobsBody = document.getElementById("privateJobsBody");
        
        // Default admin credentials (you can change these)
        const ADMIN_USERNAME = "admin";
        const ADMIN_PASSWORD = "password123";
        
        // Toggle admin panel
        adminToggle.addEventListener("click", () => {
            adminPanel.classList.toggle("show");
        });
        
        // Login functionality
        loginBtn.addEventListener("click", () => {
            const username = document.getElementById("adminUsername").value;
            const password = document.getElementById("adminPassword").value;
            
            if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
                adminLogin.style.display = "none";
                adminJobForm.classList.add("show");
            } else {
                alert("Invalid username or password!");
            }
        });
        
        // Logout functionality
        logoutBtn.addEventListener("click", () => {
            adminJobForm.classList.remove("show");
            adminLogin.style.display = "block";
            document.getElementById("adminUsername").value = "";
            document.getElementById("adminPassword").value = "";
        });
        
        // Add job functionality - MODIFIED TO INSERT INTO CORRECT TABLE
        addJobBtn.addEventListener("click", () => {
            const jobTitle = document.getElementById("jobTitle").value;
            const jobDept = document.getElementById("jobDept").value;
            const jobLocation = document.getElementById("jobLocation").value;
            const jobQualification = document.getElementById("jobQualification").value;
            const jobSalary = document.getElementById("jobSalary").value;
            const jobCategory = document.getElementById("jobCategory").value;
            
            if (!jobTitle || !jobDept || !jobLocation || !jobQualification || !jobSalary) {
                alert("Please fill all fields!");
                return;
            }
            
            // Determine which table to add the job to based on category
            let targetTableBody, isGovtJob;
            
            if (jobCategory === "govt") {
                targetTableBody = govtJobsBody;
                isGovtJob = true;
            } else {
                targetTableBody = privateJobsBody;
                isGovtJob = false;
            }
            
            // Create new row
            const newRow = document.createElement("tr");
            const rowNumber = targetTableBody.children.length + 1;
            
            // Add job to the correct table based on category
            if (isGovtJob) {
                newRow.innerHTML = `
                    <td>${rowNumber}</td>
                    <td>${jobTitle}</td>
                    <td>${jobDept}</td>
                    <td>${jobLocation}</td>
                    <td>${jobQualification}</td>
                    <td>${jobSalary}</td>
                    <td><button class="apply-btn">Apply Now</button></td>
                `;
            } else {
                newRow.innerHTML = `
                    <td>${rowNumber}</td>
                    <td>${jobTitle}</td>
                    <td>${jobDept}</td>
                    <td>${jobLocation}</td>
                    <td>${jobQualification}</td>
                    <td>${jobSalary}</td>
                    <td><button class="apply-btn">Apply Now</button></td>
                `;
            }
            
            // Add the new row to the correct table
            targetTableBody.appendChild(newRow);
            
            // Reset form
            document.getElementById("jobTitle").value = "";
            document.getElementById("jobDept").value = "";
            document.getElementById("jobLocation").value = "";
            document.getElementById("jobQualification").value = "";
            document.getElementById("jobSalary").value = "";
            
            alert("Job added successfully to " + (isGovtJob ? "Government Jobs" : "Private Jobs") + "!");
        });

        // Original job filtering functionality
        const searchInput = document.getElementById("searchInput");
        const deptFilter = document.getElementById("deptFilter");
        const clearBtn = document.getElementById("clearBtn");
        const jobCards = document.querySelectorAll(".job-card-container");

        function filterJobs() {
            const searchValue = searchInput.value.toLowerCase().trim();
            const deptValue = deptFilter.value.toLowerCase().trim();

            jobCards.forEach(card => {
                const title = card.dataset.title.toLowerCase();
                const dept = card.dataset.dept.toLowerCase();
                const location = card.dataset.location.toLowerCase();

                const matchesSearch = !searchValue ||
                    title.includes(searchValue) ||
                    dept.includes(searchValue) ||
                    location.includes(searchValue);

                const matchesDept = !deptValue || dept === deptValue;

                if (matchesSearch && matchesDept) {
                    card.classList.remove("hidden-card");
                    card.style.display = "block";
                } else {
                    card.classList.add("hidden-card");
                    card.style.display = "none";
                }
            });
        }

        searchInput.addEventListener("input", filterJobs);
        deptFilter.addEventListener("change", filterJobs);
        clearBtn.addEventListener("click", () => {
            searchInput.value = "";
            deptFilter.value = "";
            filterJobs();
        });

        // Mobile menu toggle
        const mobileMenuBtn = document.getElementById("mobileMenuBtn");
        const mobileMenu = document.getElementById("mobileMenu");
        
        mobileMenuBtn.addEventListener("click", () => {
            mobileMenu.classList.toggle("show");
        });

        // Initialize filter on page load
        filterJobs();
    </script>
</body>
</html>