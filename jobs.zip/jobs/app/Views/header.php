<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tamil Nadu Job Portal - Premium Interactive</title>
    
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            scroll-behavior: smooth;
            background: #f3f4f6;
        }

        /* Enhanced Banner Styles */
        .enhanced-banner {
            position: relative;
            background: linear-gradient(135deg, #0066ff, #00c2ff);
            color: white;
            text-align: center;
            padding: 80px 20px;
            border-radius: 25px;
            overflow: hidden;
            border: 4px solid rgba(255, 255, 255, 0.9);
            box-shadow: 0 15px 45px rgba(0, 0, 0, 0.5);
            transition: all 0.3s ease-in-out;
        }

        .enhanced-banner:hover {
            box-shadow: 0 20px 55px rgba(0, 0, 0, 0.7);
            transform: scale(1.02);
            border-color: #ffffff;
        }

        .enhanced-banner h1 {
            font-size: 2.8rem;
            font-weight: 700;
            margin-bottom: 20px;
            text-shadow: 3px 3px 10px rgba(0,0,0,0.3);
        }

        .enhanced-banner p {
            font-size: 1.2rem;
            font-weight: 400;
            max-width: 650px;
            margin: 0 auto 30px;
            text-shadow: 2px 2px 8px rgba(0,0,0,0.3);
        }

        .btn-custom {
            background-color: #fff;
            color: #0066ff;
            font-weight: 600;
            border-radius: 30px;
            padding: 12px 28px;
            border: none;
            box-shadow: 0 5px 20px rgba(255, 255, 255, 0.3);
            transition: all 0.3s ease;
        }

        .btn-custom:hover {
            background-color: #0066ff;
            color: #fff;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.5);
        }

        /* Header Styles */
        .custom-header {
            background: linear-gradient(to bottom, #e0e7ff, #dbeafe);
            backdrop-filter: blur(10px);
            position: sticky;
            top: 0;
            z-index: 50;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
        }

        .logo-text {
            font-size: 1.75rem;
            font-weight: 800;
            background: linear-gradient(to right, #4f46e5, #06b6d4);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .nav-link-custom {
            color: #374151;
            font-weight: 500;
            font-size: 0.9rem;
            transition: color 0.3s;
        }

        .nav-link-custom:hover {
            color: #4f46e5;
        }

        .explore-btn {
            background-color: #4f46e5;
            color: white;
            font-weight: 600;
            padding: 0.5rem 1.25rem;
            border-radius: 1rem;
            box-shadow: 0 4px 6px rgba(79, 70, 229, 0.3);
            transition: all 0.3s;
        }

        .explore-btn:hover {
            background-color: #4338ca;
            box-shadow: 0 6px 8px rgba(79, 70, 229, 0.4);
        }

        /* Job Card Styles */
        .job-card-container {
            transition: all 0.35s ease-in-out;
            border-radius: 1rem;
            background: white;
            padding: 1.5rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            border: 1px solid transparent;
        }

        .job-card-container:hover {
            transform: translateY(-6px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            background: linear-gradient(to right, #ffffff, #f0f7ff);
            border-color: #dbeafe;
        }

        .apply-btn {
            background-color: #4f46e5;
            color: white;
            font-weight: 600;
            padding: 0.5rem 1.25rem;
            border-radius: 0.75rem;
            border: none;
            transition: all 0.3s;
        }

        .apply-btn:hover {
            background: linear-gradient(to right, #4f46e5, #3730a3);
            box-shadow: 0 0 10px rgba(79, 70, 229, 0.4);
        }

        .hidden-card {
            opacity: 0;
            transform: scale(0.97);
            pointer-events: none;
            height: 0;
            margin: 0;
            padding: 0;
            border: none;
        }

        /* Section Backgrounds */
        .govt-bg {
            background: linear-gradient(160deg, #e0e7ff 0%, #f0f9ff 100%);
            border-radius: 1.5rem;
            padding: 2.5rem;
            box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1);
        }

        .private-bg {
            background: linear-gradient(160deg, #d1fae5 0%, #fef9c3 100%);
            border-radius: 1.5rem;
            padding: 2.5rem;
            box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1);
        }

        /* Filter Section */
        .filter-section {
            background: white;
            border-radius: 1.5rem;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            padding: 2rem;
        }

        .search-input {
            border-radius: 1rem;
            border: 1px solid #d1d5db;
            padding: 0.75rem 1.25rem;
            transition: all 0.3s;
        }

        .search-input:focus {
            outline: none;
            border-color: #4f46e5;
            box-shadow: 0 0 0 4px rgba(79, 70, 229, 0.1);
        }

        .dept-select {
            border-radius: 1rem;
            border: 1px solid #d1d5db;
            padding: 0.75rem 1.25rem;
            background: white;
        }

        .clear-btn {
            border-radius: 1rem;
            padding: 0.75rem 1.25rem;
            background: white;
            border: 1px solid #e5e7eb;
            font-weight: 600;
            transition: all 0.3s;
        }

        .clear-btn:hover {
            background: #f9fafb;
        }

        /* Job Table Section */
        .job-section {
            background: white;
            border-radius: 1.5rem;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            padding: 2rem;
            margin-bottom: 3rem;
        }

        .job-section h2 {
            font-weight: 700;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .table-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.95rem;
        }

        th, td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid #e5e7eb;
        }

        th {
            background: linear-gradient(90deg, #4f46e5, #06b6d4);
            color: white;
            font-weight: 600;
            white-space: nowrap;
        }

        tr:hover {
            background: #f9fafb;
        }

        /* Footer Styles - COMPACT VERSION */
        .custom-footer {
            background: linear-gradient(to right, #e0e7ff, #dbeafe);
            border-top: 1px solid #c7d2fe;
            padding: 2rem 0 1rem;
            margin-top: 3rem;
        }

        .footer-heading {
            font-size: 1.5rem;
            font-weight: 800;
            background: linear-gradient(to right, #4f46e5, #06b6d4);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 1rem;
        }

        .footer-description {
            font-size: 0.9rem;
            color: #6b7280;
            margin-bottom: 1.5rem;
            max-width: 500px;
            margin-left: auto;
            margin-right: auto;
        }

        .social-links-compact {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 0.5rem;
            margin-bottom: 1.5rem;
        }

        .social-link-compact {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 0.75rem;
            border-radius: 0.5rem;
            background: white;
            border: 1px solid #e5e7eb;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            transition: all 0.3s;
            text-decoration: none;
            color: #374151;
            font-weight: 500;
            font-size: 0.85rem;
        }

        .social-link-compact:hover {
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transform: translateY(-2px);
        }

        .social-link-compact.whatsapp:hover {
            border-color: #10b981;
        }

        .social-link-compact.telegram:hover {
            border-color: #0ea5e9;
        }

        .social-link-compact.linkedin:hover {
            border-color: #3b82f6;
        }

        .social-link-compact.facebook:hover {
            border-color: #3b82f6;
        }

        .social-link-compact.youtube:hover {
            border-color: #ef4444;
        }

        .social-link-compact.twitter:hover {
            border-color: #0ea5e9;
        }

        .footer-copyright {
            font-size: 0.8rem;
            color: #6b7280;
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 1px solid #d1d5db;
        }

        /* Tag Styles */
        .tag {
            font-size: 0.75rem;
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-weight: 500;
        }

        .tag-tnpsc {
            background: #e0e7ff;
            color: #3730a3;
        }

        .tag-railway {
            background: #d1fae5;
            color: #065f46;
        }

        .tag-it {
            background: #dbeafe;
            color: #1e40af;
        }

        .tag-marketing {
            background: #fef3c7;
            color: #92400e;
        }

        .tag-location {
            background: #f3f4f6;
            color: #374151;
        }

        /* Mobile Menu */
        #mobileMenu {
            display: none;
        }

        #mobileMenu.show {
            display: flex;
            flex-direction: column;
            gap: 1rem;
            margin-top: 1rem;
        }

        /* Admin Panel Styles */
        .admin-panel {
            background: white;
            border-radius: 1.5rem;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            padding: 2rem;
            margin-bottom: 3rem;
            display: none;
        }

        .admin-panel.show {
            display: block;
        }

        .admin-toggle {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 100;
            background: #4f46e5;
            color: white;
            border: none;
            border-radius: 50%;
            width: 60px;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 10px rgba(79, 70, 229, 0.3);
            cursor: pointer;
            transition: all 0.3s;
        }

        .admin-toggle:hover {
            background: #4338ca;
            transform: scale(1.1);
        }

        .login-form {
            max-width: 400px;
            margin: 0 auto;
            padding: 2rem;
            background: white;
            border-radius: 1rem;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-label {
            font-weight: 600;
            margin-bottom: 0.5rem;
            display: block;
        }

        .form-control {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 1px solid #d1d5db;
            border-radius: 0.75rem;
            transition: all 0.3s;
        }

        .form-control:focus {
            outline: none;
            border-color: #4f46e5;
            box-shadow: 0 0 0 4px rgba(79, 70, 229, 0.1);
        }

        .admin-btn {
            background: #4f46e5;
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 0.75rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            width: 100%;
        }

        .admin-btn:hover {
            background: #4338ca;
        }

        .admin-btn.secondary {
            background: #6b7280;
        }

        .admin-btn.secondary:hover {
            background: #4b5563;
        }

        .job-form {
            display: none;
        }

        .job-form.show {
            display: block;
        }

        @media (max-width: 768px) {
            .enhanced-banner {
                padding: 60px 20px;
            }
            
            .filter-section .d-flex {
                flex-direction: column;
            }
            
            .filter-section .d-flex > * {
                width: 100%;
                margin-bottom: 1rem;
            }
            
            .social-links-compact {
                flex-direction: column;
                align-items: center;
            }
            
            .social-link-compact {
                width: 100%;
                max-width: 200px;
                justify-content: center;
            }
            
            th, td {
                padding: 0.75rem;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="custom-header py-3">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center">
            <h1 class="logo-text m-0" style="font-size:32px;">
    <a href="<?= base_url('/') ?>" style="color:inherit; text-decoration:none; font-size:inherit;">
        Tamil Nadu Job Portal
    </a>
</h1>
                
                <nav class="d-none d-md-flex gap-4 align-items-center">
                    <a href="<?= base_url('jobs/category/TN-Govt-Jobs') ?>" class="nav-link-custom text-decoration-none">TN Govt Jobs</a>
                    <a href="<?= base_url('jobs/category/Central-Govt-Jobs') ?>" class="nav-link-custom text-decoration-none">Central Govt Jobs</a>
                    <a href="<?= base_url('jobs/category/TNPSC-Jobs') ?>" class="nav-link-custom text-decoration-none">TNPSC Jobs</a>
                    <a href="<?= base_url('jobs/category/Bank-Jobs') ?>" class="nav-link-custom text-decoration-none">Bank Jobs</a>
                    <a href="<?= base_url('jobs/category/Railway-Jobs') ?>" class="nav-link-custom text-decoration-none">Railway Jobs</a>
                    <a href="<?= base_url('jobs/category/Private-Jobs') ?>" class="nav-link-custom text-decoration-none">Private Jobs</a>
                    <a href="#jobs" class="explore-btn text-decoration-none">🔍 Explore Jobs</a>
                </nav>
                
                <button id="mobileMenuBtn" class="d-md-none btn text-indigo-600 fs-4">☰</button>
            </div>
            
            <div id="mobileMenu" class="d-md-none">
                <a href="#tn-govt" class="nav-link-custom text-decoration-none py-2">TN Govt Jobs</a>
                <a href="#central-govt" class="nav-link-custom text-decoration-none py-2">Central Govt Jobs</a>
                <a href="#tnpsc" class="nav-link-custom text-decoration-none py-2">TNPSC Jobs</a>
                <a href="#bank" class="nav-link-custom text-decoration-none py-2">Bank Jobs</a>
                <a href="#railway" class="nav-link-custom text-decoration-none py-2">Railway Jobs</a>
                <a href="#private" class="nav-link-custom text-decoration-none py-2">Private Jobs</a>
            </div>
        </div>
    </header>